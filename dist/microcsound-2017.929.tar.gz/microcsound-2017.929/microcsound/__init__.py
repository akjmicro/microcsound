# -*- coding: utf-8  -*-

''' microcsound, a front end for composition with Csound, with an
emphasis on pitch flexibility/microtonality. '''
